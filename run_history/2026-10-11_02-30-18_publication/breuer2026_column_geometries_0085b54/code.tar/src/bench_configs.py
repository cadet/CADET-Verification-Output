# -*- coding: utf-8 -*-
"""

This script defines benchmark configurations, e.g. whether or not to include
sensitivities, the considered numerical methods, etc.
The individual model settings considered are specified in the CADET-Database
github project.

"""

import os
import json
import copy
from functools import partial

import src.bench_func as bench_func
import src.utility.convergence as convergence
from src import analytical
from src import geometry_references

from src.benchmark_models import settings_2Dchromatography
from src.benchmark_models import settings_columnSystems
from src.benchmark_models import setting_Col1D_lin_1comp_benchmark1
from src.benchmark_models import setting_Col1D_SMA_4comp_LWE_benchmark1
from src.benchmark_models import setting_radCol1D_LRM_lin_1comp_benchmark1
from src.benchmark_models import setting_radCol1D_lin_1comp_benchmark1
from src.benchmark_models import setting_COL1D_GRMparType2_dynLin_2comp_benchmark1
from src.benchmark_models import setting_Col1D_XparTypeGR_lin_1comp_benchmark1
from src.benchmark_models import setting_Col1D_langLRM_2comp_benchmark1
from src.benchmark_models import setting_Col1D_pureTransport_1comp_benchmark1
from src.benchmark_models.setting_Col1D_pureTransport_1comp_benchmark1 import create_convergence_object


# %% benchmark templates

# TODO add Langmuir setting used in Breuer et al

_benchmark_settings_ = [
    'full_chromatography_benchmark',
    'chromatography_benchmark_without_GRMLWE',
    'linear_chromatography_benchmark',
    'LWE_chromatography_benchmark',
    'radial_flow_benchmark_fv',
    'radial_flow_benchmark_dg',
    # Individual settings
    'LRM_dynLin_1comp_benchmark1',
    'LRMP_dynLin_1comp_benchmark1',
    'GRM_dynLin_1comp_benchmark1',
    'LRM_reqSMA_4comp_benchmark1',
    'LRMP_reqSMA_4comp_benchmark1',
    'GRM_reqSMA_4comp_benchmark1',
    'LRM_langmuir_2comp_benchmark1'
]

# %%


def run_benchmark(
        setting, disc_methods, cadet_path, output_path, database_path,
        n_jobs=-1, benchmark_size='mid', include_sensitivity=False, ref_files=None,
        N_RUNS=1, **kwargs):
    """ Runs and saves a convergence/performance benchmark.

    Parameters
    ----------
    cadet_path : String 
        absolute path to CADET executable.
    output_path : String 
        absolute path to output folder.
    N_RUNS : Int 
        Number of runs. For multiple runs, the simulation times
        are overwritten by the best/fastest. The saved h5 files will still hold
        the compute times of the last run. Defaults to one
    Returns
    -------
    List of Strings
        Names of result json files.
    """

    if setting not in _benchmark_settings_:
        raise ValueError('Unknown setting ' + str(setting) + '.')

    cadet_config_jsons = []
    include_sens = []
    ref_files_ = []
    unit_IDs = []
    which = []
    idas_abstol = []
    ax_methods = []
    ax_discs = []
    par_methods = []
    par_discs = []

    for methodIdx in range(len(disc_methods)):
        addition = eval(setting)(
            disc_methods[methodIdx], benchmark_size, include_sensitivity, ref_files)
        add_benchmark(
            cadet_config_jsons, include_sens, ref_files_, unit_IDs, which,
            idas_abstol, ax_methods, ax_discs, par_methods, par_discs,
            addition)

    os.makedirs(output_path, exist_ok=True)

    first_iteration = True

    while True:

        # run convergence benchmark
        results = bench_func.run_convergence_analysis(
            database_path=database_path, output_path=output_path,
            cadet_path=cadet_path,
            cadet_config_jsons=cadet_config_jsons,
            include_sens=include_sens,
            ref_files=ref_files_,
            unit_IDs=unit_IDs,
            which=which,
            ax_methods=ax_methods,
            ax_discs=ax_discs,
            par_methods=par_methods,
            par_discs=par_discs,
            idas_abstol=idas_abstol,
            n_jobs=n_jobs,
            rerun_sims=bool(N_RUNS),
            **kwargs
        )

        if first_iteration:
            sim_times = copy.deepcopy(ax_discs)

        # get simulation times
        for resultIdx in range(len(results)):
            try:
                with open(output_path / results[resultIdx], 'r') as json_file:

                    data = json.load(json_file)['convergence']

                    for methodIdx in range(len(ax_methods[resultIdx])):

                        axMethod = ax_methods[resultIdx][methodIdx]
                        if axMethod == 0:
                            method_string = "FV"
                        else:
                            method_string = "DG_P" + \
                                str(axMethod) if axMethod > 0 else "FV"
                            if par_methods[resultIdx][methodIdx] is not None:
                                method_string += "parP" + \
                                    str(par_methods[resultIdx][methodIdx])

                        sim_times[resultIdx][methodIdx] = data[method_string][which[resultIdx]]['Sim. time']

            except FileNotFoundError:
                raise Exception('file not found')

        if first_iteration:
            sim_times_old = sim_times
            N_RUNS = N_RUNS - 1
            first_iteration = False
            if N_RUNS <= 0:
                break
            else:
                continue
        else:  # sim_times has the new compute times, sim_times_old the old ones
            # get smallest compute time each and write into file!
            sim_times = [[min(a, b) for a, b in zip(sub_list1, sub_list2)]
                         for sub_list1, sub_list2 in zip(sim_times, sim_times_old)]

            for resultIdx in range(len(results)):
                try:
                    with open(output_path / results[resultIdx], 'r') as json_file:

                        json_data = json.load(json_file)

                        for methodIdx in range(len(ax_methods[resultIdx])):

                            axMethod = ax_methods[resultIdx][methodIdx]
                            if axMethod == 0:
                                method_string = "FV"
                            else:
                                method_string = "DG_P" + \
                                    str(axMethod) if axMethod > 0 else "FV"
                                if par_methods[resultIdx][methodIdx] is not None:
                                    method_string += "parP" + \
                                        str(par_methods[resultIdx][methodIdx])

                            json_data['convergence'][method_string][which[resultIdx]
                                                                    ]['Sim. time'] = sim_times[resultIdx][methodIdx]

                    # Write the updated data back to the JSON file
                    with open(output_path / results[resultIdx], 'w') as json_file:
                        json.dump(json_data, json_file, indent=4)

                except FileNotFoundError:
                    raise Exception('file not found')

            sim_times_old = sim_times

        N_RUNS = N_RUNS - 1
        if N_RUNS <= 0:
            break

    return results


def axial_flow_benchmark_fv(small_test=False, sensitivities=False, ref_filepath=None):

    # Load analytical references for linear 1-component benchmarks
    if ref_filepath is not None:
        ref_LRM = convergence.get_solution(ref_filepath+'/CASEMA_reference/LRM_dynLin_1comp_benchmark1.h5')
        ref_LRMP = convergence.get_solution(ref_filepath+'/CASEMA_reference/LRMP_dynLin_1comp_benchmark1.h5')
        ref_GRM = convergence.get_solution(ref_filepath+'/CASEMA_reference/GRM_dynLin_1comp_benchmark1.h5')
        ref_GRMsd = convergence.get_solution(ref_filepath+'/CASEMA_reference/GRMsd_dynLin_1comp_benchmark1.h5')
        ref_LRMlangmuir = convergence.get_solution(ref_filepath+'/CADET-Core_reference/chromatography/LRM_lang_2comp_benchmark1.h5')
    else:
        ref_LRM = None
        ref_LRMP = None
        ref_GRM = None
        ref_GRMsd = None
        ref_LRMlangmuir = None

    n_settings = 9

    benchmark_config = {
        'cadet_config_jsons': [
            setting_Col1D_lin_1comp_benchmark1.get_model(
                spatial_method_bulk=0, particle_type='EQUILIBRIUM_PARTICLE'
                ),
            setting_Col1D_lin_1comp_benchmark1.get_model(
                spatial_method_bulk=0, particle_type='HOMOGENEOUS_PARTICLE'
                ),
            setting_Col1D_lin_1comp_benchmark1.get_model(
               spatial_method_bulk=0, spatial_method_particle=0,
               particle_type='GENERAL_RATE_PARTICLE'
               ),
            setting_Col1D_lin_1comp_benchmark1.get_model(
               spatial_method_bulk=0, spatial_method_particle=0,
               particle_type='GENERAL_RATE_PARTICLE', surface_diffusion=5E-11
               ),
            setting_Col1D_SMA_4comp_LWE_benchmark1.get_model(
                spatial_method_bulk=0, particle_type='EQUILIBRIUM_PARTICLE'
                ),
            setting_Col1D_SMA_4comp_LWE_benchmark1.get_model(
               spatial_method_bulk=0, particle_type='HOMOGENEOUS_PARTICLE'
               ),
           setting_Col1D_SMA_4comp_LWE_benchmark1.get_model(
              spatial_method_bulk=0, spatial_method_particle=0,
              particle_type='GENERAL_RATE_PARTICLE'
              ),
           setting_Col1D_XparTypeGR_lin_1comp_benchmark1.get_model(
               spatial_method_bulk=0, spatial_method_particle=0,
            **{ # 4parType:
                'par_method': 0,
                'npartype': 2 if small_test else 4,
                'par_type_volfrac': [0.5, 0.5] if small_test else [0.3, 0.35, 0.15, 0.2],
                'par_radius': [45E-6, 75E-6] if small_test else [45E-6, 75E-6, 25E-6, 60E-6],
                'par_porosity': [0.75, 0.7] if small_test else [0.75, 0.7, 0.8, 0.65],
                'nbound': [1, 1] if small_test else [1, 1, 0, 1],
                'init_cp': [0.0, 0.0] if small_test else [0.0, 0.0, 0.0, 0.0],
                'init_cs': [0.0, 0.0] if small_test else [0.0, 0.0, 0.0, 0.0],
                'film_diffusion': [6.9E-6, 6E-6] if small_test else [6.9E-6, 6E-6, 6.5E-6, 6.7E-6],
                'pore_diffusion': [5E-11, 3E-11] if small_test else [6.07E-11, 5E-11, 3E-11, 4E-11],
                'surface_diffusion': [5E-11, 0.0] if small_test else [1E-11, 5E-11, 0.0, 0.0],
                'adsorption_model': ['LINEAR', 'LINEAR'] if small_test else ['LINEAR', 'LINEAR', 'NONE', 'LINEAR'],
                'is_kinetic': [0, 1] if small_test else [0, 1, 0, 0],
                'lin_ka': [35.5, 4.5] if small_test else [35.5, 4.5, 0, 0.25],
                'lin_kd': [1.0, 0.15] if small_test else [1.0, 0.15, 0, 1.0]
            }),
            setting_Col1D_langLRM_2comp_benchmark1.get_model(
                spatial_method_bulk=0
                )
        ],
        'cadet_config_names': [
            'LRM_dynLin_1comp_benchmark1',
            'LRMP_dynLin_1comp_benchmark1',
            'GRM_dynLin_1comp_benchmark1',
            'GRMsd_dynLin_1comp_benchmark1',
            'LRM_reqSMA_4comp_benchmark1',
            'LRMP_reqSMA_4comp_benchmark1',
            'GRM_reqSMA_4comp_benchmark1',
            'GRM_4parTypeLin_4comp_benchmark1',
            'LRM_langmuir_2comp_benchmark1'

        ],
        'include_sens': [True] * n_settings if sensitivities else [False] * n_settings,
        'ref_files': [
            [ref_LRM], [ref_LRMP], [ref_GRM], [ref_GRMsd],
            [None], [None], [None], [None], [ref_LRMlangmuir]
        ],
        'unit_IDs': [
            '001', '001', '001', '001', '000', '000', '000', '001', '001'
        ],
        'which': [
            'outlet', 'outlet', 'outlet', 'outlet', 'outlet', 'outlet', 'outlet', 'outlet', 'outlet'
        ],
        'idas_abstol': [
            [1e-12], [1e-12], [1e-12], [1e-12], [1e-10], [1e-10], [1e-8], [1e-6], [1e-8]
        ],
        'ax_methods': [
            [0], [0], [0], [0], [0], [0], [0], [0], [0]
        ],
        'ax_discs': [
            [bench_func.disc_list(8, 8 if not small_test else 3)],
            [bench_func.disc_list(8, 8 if not small_test else 3)],
            [bench_func.disc_list(8, 8 if not small_test else 3)],
            [bench_func.disc_list(8, 8 if not small_test else 3)],
            [bench_func.disc_list(8, 6 if not small_test else 3)],
            [bench_func.disc_list(8, 6 if not small_test else 3)],
            [bench_func.disc_list(8, 6 if not small_test else 3)],
            [bench_func.disc_list(8, 4 if not small_test else 3)],
            [bench_func.disc_list(32, 9 if not small_test else 3)]
        ],
        'par_methods': [
            [None], [None], [0], [0], [None], [None], [0], [0], [None]
        ],
        'par_discs': [
            [None],
            [None],
            [bench_func.disc_list(1, 8 if not small_test else 3)],
            [bench_func.disc_list(1, 8 if not small_test else 3)],
            [None],
            [None],
            [bench_func.disc_list(1, 6 if not small_test else 3)],
            [bench_func.disc_list(1, 4 if not small_test else 3)],
            [None]
        ],
        'disc_refinement_functions' : [
            [bench_func.create_object_from_config] for _ in range(n_settings)
            ]
    }

    return benchmark_config


def axial_flow_benchmark_dg(small_test=False, sensitivities=False, ref_filepath=None):

    # Load analytical references for linear 1-component benchmarks
    if ref_filepath is not None:
        ref_LRM = convergence.get_solution(ref_filepath+'/CASEMA_reference/LRM_dynLin_1comp_benchmark1.h5')
        ref_LRMP = convergence.get_solution(ref_filepath+'/CASEMA_reference/LRMP_dynLin_1comp_benchmark1.h5')
        ref_GRM = convergence.get_solution(ref_filepath+'/CASEMA_reference/GRM_dynLin_1comp_benchmark1.h5')
        ref_GRMsd = convergence.get_solution(ref_filepath+'/CASEMA_reference/GRMsd_dynLin_1comp_benchmark1.h5')
        ref_LRMlangmuir = convergence.get_solution(ref_filepath+'/CADET-Core_reference/chromatography/LRM_lang_2comp_benchmark1.h5')
    else:
        ref_LRM = None
        ref_LRMP = None
        ref_GRM = None
        ref_GRMsd = None
        ref_LRMlangmuir = None

    n_settings = 9

    benchmark_config = {
        'cadet_config_jsons': [
            setting_Col1D_lin_1comp_benchmark1.get_model(
                spatial_method_bulk=3, particle_type='EQUILIBRIUM_PARTICLE'
                ),
            setting_Col1D_lin_1comp_benchmark1.get_model(
                spatial_method_bulk=3, particle_type='HOMOGENEOUS_PARTICLE'
                ),
            setting_Col1D_lin_1comp_benchmark1.get_model(
               spatial_method_bulk=3, spatial_method_particle=3,
               particle_type='GENERAL_RATE_PARTICLE'
               ),
            setting_Col1D_lin_1comp_benchmark1.get_model(
               spatial_method_bulk=3, spatial_method_particle=3,
               particle_type='GENERAL_RATE_PARTICLE', surface_diffusion=5E-11
               ),
            setting_Col1D_SMA_4comp_LWE_benchmark1.get_model(
                spatial_method_bulk=3, particle_type='EQUILIBRIUM_PARTICLE'
                ),
            setting_Col1D_SMA_4comp_LWE_benchmark1.get_model(
                spatial_method_bulk=3, particle_type='HOMOGENEOUS_PARTICLE'
                ),
            setting_Col1D_SMA_4comp_LWE_benchmark1.get_model(
               spatial_method_bulk=3, spatial_method_particle=3,
               particle_type='GENERAL_RATE_PARTICLE'
               ),
            setting_Col1D_XparTypeGR_lin_1comp_benchmark1.get_model(
                spatial_method_bulk=0, spatial_method_particle=0,
             **{ # 4parType:
                 'par_method': 0,
                 'npartype': 2 if small_test else 4,
                 'par_type_volfrac': [0.5, 0.5] if small_test else [0.3, 0.35, 0.15, 0.2],
                 'par_radius': [45E-6, 75E-6] if small_test else [45E-6, 75E-6, 25E-6, 60E-6],
                 'par_porosity': [0.75, 0.7] if small_test else [0.75, 0.7, 0.8, 0.65],
                 'nbound': [1, 1] if small_test else [1, 1, 0, 1],
                 'init_cp': [0.0, 0.0] if small_test else [0.0, 0.0, 0.0, 0.0],
                 'init_cs': [0.0, 0.0] if small_test else [0.0, 0.0, 0.0, 0.0],
                 'film_diffusion': [6.9E-6, 6E-6] if small_test else [6.9E-6, 6E-6, 6.5E-6, 6.7E-6],
                 'pore_diffusion': [5E-11, 3E-11] if small_test else [6.07E-11, 5E-11, 3E-11, 4E-11],
                 'surface_diffusion': [5E-11, 0.0] if small_test else [1E-11, 5E-11, 0.0, 0.0],
                 'adsorption_model': ['LINEAR', 'LINEAR'] if small_test else ['LINEAR', 'LINEAR', 'NONE', 'LINEAR'],
                 'is_kinetic': [0, 1] if small_test else [0, 1, 0, 0],
                 'lin_ka': [35.5, 4.5] if small_test else [35.5, 4.5, 0, 0.25],
                 'lin_kd': [1.0, 0.15] if small_test else [1.0, 0.15, 0, 1.0]
             }),
            setting_Col1D_langLRM_2comp_benchmark1.get_model(
                spatial_method_bulk=3
                )
        ],
        'cadet_config_names': [
            'LRM_dynLin_1comp_benchmark1',
            'LRMP_dynLin_1comp_benchmark1',
            'GRM_dynLin_1comp_benchmark1',
            'GRMsd_dynLin_1comp_benchmark1',
            'LRM_reqSMA_4comp_benchmark1',
            'LRMP_reqSMA_4comp_benchmark1',
            'GRM_reqSMA_4comp_benchmark1',
            'GRM_4parTypeLin_4comp_benchmark1',
            'LRM_langmuir_2comp_benchmark1'
        ],
        'include_sens': [True] * n_settings if sensitivities else [False] * n_settings,
        'ref_files': [
            [ref_LRM], [ref_LRMP], [ref_GRM], [ref_GRMsd],
            [None], [None], [None], [None], [ref_LRMlangmuir]
        ],
        'unit_IDs': [
            '001', '001', '001', '001', '000', '000', '000', '001', '001'
        ],
        'which': [
            'outlet'
        ] * n_settings,
        'idas_abstol': [
           [1e-12], [1e-12], [1e-12], [1e-12], [1e-10], [1e-10], [1e-8], [1e-6], [1e-10]
        ],
        'ax_methods': [
            [3], [3], [3], [3], [3], [3], [3], [2], [3]
        ],
        'ax_discs': [
            [bench_func.disc_list(1, 8 if not small_test else 3)],
            [bench_func.disc_list(1, 9 if not small_test else 3)],
            [bench_func.disc_list(8, 5 if not small_test else 3)],
            [bench_func.disc_list(8, 5 if not small_test else 3)],
            [bench_func.disc_list(4, 6 if not small_test else 3)],
            [bench_func.disc_list(4, 6 if not small_test else 3)],
            [bench_func.disc_list(4, 5 if not small_test else 3)],
            [bench_func.disc_list(2, 4 if not small_test else 3)],
            [bench_func.disc_list(8, 7 if not small_test else 3)]
        ],
        'par_methods': [
            [None], [None], [3], [3], [None], [None], [3], [2], [None]
        ],
        'par_discs': [
            [None],
            [None],
            [bench_func.disc_list(1, 5 if not small_test else 3)],
            [bench_func.disc_list(1, 5 if not small_test else 3)],
            [None],
            [None],
            [bench_func.disc_list(1, 5 if not small_test else 3)],
            [bench_func.disc_list(1, 4 if not small_test else 3)],
            [None]
        ],
        'disc_refinement_functions' : [
            [bench_func.create_object_from_config] for _ in range(n_settings)
            ]
    }

    return benchmark_config


def paper_geometry_test_benchmark(setting_name,
                             small_test=False, ref_filepath=None,
                             user_solution_times_unit_state=[1.25],
                            **model_kwargs
                             ):

    reference = analytical.load_reference(setting_name, ref_filepath)

    n_settings = 1
    
    benchmark_config = {
        'cadet_config_jsons': [
            setting_Col1D_pureTransport_1comp_benchmark1.get_model(
                spatial_method_bulk=0,
                write_solution_bulk=True,
                **model_kwargs
                ),
        ],
        'cadet_config_names': [
            setting_name,
        ],
        'include_sens': [False] * n_settings,
        'ref_files': [
            [reference]
        ],
        'unit_IDs': [
            '001',
        ],
        'which': [
            'bulk' # requires exactly one of the kwargs time_point or normed_coord
            # 'outlet'
        ] * n_settings,
        'idas_abstol': [
            [1e-15],
        ],
        'ax_methods': [
            [0]
        ],
        'ax_discs': [
            [bench_func.disc_list(1, 13 if not small_test else 3)],
        ],
        'par_methods': [
            [None],
        ],
        'par_discs': [
            [None],
        ],
        'disc_refinement_functions' : [
            [partial(create_convergence_object, setting_name=setting_name, model_kwargs={**model_kwargs, 'spatial_method_bulk': 0}, user_solution_times_unit_state=user_solution_times_unit_state)] for _ in range(n_settings)
             ]
    }

    return benchmark_config


def paper_geometry_transport_benchmark(setting_name,
                             small_test=False, ref_filepath=None,
                             cadet_reference=None,
                            **model_kwargs
                             ):
    """Pure transport EOC benchmark of one column geometry.

    Compared against the analytical solution where one exists, otherwise against
    the stored CADET reference named by cadet_reference, and otherwise against the
    finest resolution of the sweep itself, see src/geometry_references.py.

    The methods default to FV (0) and DG of degrees one to four. Pass
    ax_methods to restrict them, e.g. to the DG degrees for a geometry that is
    only implemented for DG, and n_levels to shorten the refinement sweeps.
    """

    default_n_levels = {0: 12, 1: 11, 2: 10, 3: 9, 4: 8}

    ax_methods = model_kwargs.pop('ax_methods', [0, 1, 2, 3, 4])
    n_levels = model_kwargs.pop(
        'n_levels', [default_n_levels[method] for method in ax_methods])
    if small_test:
        n_levels = [3] * len(ax_methods)
    ax_discs = [bench_func.disc_list(1, n) for n in n_levels]
    idas_abstol = [1e-15] * len(ax_methods)

    base_config = setting_Col1D_pureTransport_1comp_benchmark1.get_model(
        spatial_method_bulk=3, write_solution_bulk=True, **model_kwargs
    )

    # The nodal initial condition depends on the grid, so every refinement level
    # is rebuilt from scratch instead of only updating NELEM/NCOL.
    refinement_functions = [
        partial(create_convergence_object, setting_name=setting_name,
                model_kwargs={**model_kwargs, 'spatial_method_bulk': method})
        for method in ax_methods
    ]

    references = geometry_references.resolve(
        setting_name=setting_name, ax_methods=ax_methods, data_dir=ref_filepath,
        cadet_reference=cadet_reference,
    )

    n_settings = 1

    benchmark_config = {
        'cadet_config_jsons': [base_config],
        'cadet_config_names': [setting_name],
        'include_sens': [False] * n_settings,
        'ref_files': [references],
        'unit_IDs': ['001'],
        'which': [
            'bulk'  # requires exactly one of the kwargs time_point or normed_coord
        ] * n_settings,
        'idas_abstol': [idas_abstol],
        'ax_methods': [ax_methods],
        'ax_discs': [ax_discs],
        'par_methods': [[None] * len(ax_methods)],
        'par_discs': [[None] * len(ax_methods)],
        'disc_refinement_functions': [refinement_functions],
    }

    return benchmark_config


def paper_geometry_LRMPdynLin_benchmark(setting_name,
                             small_test=False, ref_filepath=None,
                             cadet_reference=None,
                            **kwargs
                             ):
    """Linear binding LRMP EOC benchmark of one column geometry.

    No analytical solution is available with particles, so this is compared against
    the stored CADET reference named by cadet_reference, and otherwise against the
    finest resolution of the sweep itself, see src/geometry_references.py.
    """

    ax_methods = [0, 1, 2, 3, 4]
    n_levels = [13, 13, 12, 11, 10] if not small_test else [3] * len(ax_methods)
    ax_discs = [bench_func.disc_list(1, n) for n in n_levels]
    idas_abstol = [1e-15] * len(ax_methods)

    base_config = setting_Col1D_lin_1comp_benchmark1.get_model(
        spatial_method_bulk=3, particle_type='HOMOGENEOUS_PARTICLE',
        column_geometry=kwargs['column_geometry'],
        write_solution_bulk=True, user_solution_times_unit_state=[12.0]
    )

    refinement_functions = [bench_func.create_object_from_config] * len(ax_methods)

    references = geometry_references.resolve(
        setting_name=setting_name, ax_methods=ax_methods, data_dir=ref_filepath,
        cadet_reference=cadet_reference,
    )

    n_settings = 1

    benchmark_config = {
        'cadet_config_jsons': [base_config],
        'cadet_config_names': [setting_name],
        'include_sens': [False] * n_settings,
        'ref_files': [references],
        'unit_IDs': ['001'],
        'which': [
            'bulk'  # requires exactly one of the kwargs time_point or normed_coord
        ] * n_settings,
        'idas_abstol': [idas_abstol],
        'ax_methods': [ax_methods],
        'ax_discs': [ax_discs],
        'par_methods': [[None] * len(ax_methods)],
        'par_discs': [[None] * len(ax_methods)],
        'disc_refinement_functions': [refinement_functions],
    }

    return benchmark_config


# %% Performance benchmarks of Breuer et al. (2023)


# Column geometries of the performance benchmarks of the column geometry
# publication, mapped to the prefix of their file names, so that the geometries
# do not write over one another.
GEOMETRY_NAMES = {
    'AXIAL_FLOW_CYLINDER': 'axial',
    'RADIAL_FLOW_CYLINDER_SHELL': 'radial',
    'AXIAL_FLOW_FRUSTUM': 'frustum',
    }


def langmuir_performance_benchmark(
        small_test=False, ref_file=None,
        column_geometry='AXIAL_FLOW_CYLINDER', col_dispersion=1e-7,
        idas_abstol=1e-10):
    """Performance benchmark of the two-component LRM with Langmuir binding.

    Figs. 7 and 8 of Breuer et al. (2023),
    doi:10.1016/j.compchemeng.2023.108340, on the refinement steps of the
    publication. col_dispersion defaults to the less disperse of its two
    settings.

    ref_file is the reference solution, shared by every spatial method, which is
    what makes the methods comparable to one another. Without one every series
    runs one level further and takes its own finest level as its reference.
    """

    if column_geometry not in GEOMETRY_NAMES:
        raise ValueError(
            'column_geometry must be one of ' + str(sorted(GEOMETRY_NAMES))
            + ', got ' + str(column_geometry) + '.'
            )

    # The WENO finite volume scheme and DG of degrees three to five, with their
    # refinement steps as (first level, number of levels), every level doubling
    # the resolution. Table S5, the left panel of Fig. 7, lists FV from 32 to
    # 65536 cells and both DG degrees from 8 to 1024 elements; degree five
    # repeats the steps of degree four.
    ax_methods = [0, 3, 4, 5]
    steps = {0: (32, 12), 3: (8, 8), 4: (8, 8), 5: (8, 8)}

    ax_discs = []

    for method in ax_methods:

        n_start, n_levels = steps[method]

        # A small test runs two levels fewer per series, but never fewer than
        # two, since a single level is not a convergence study.
        if small_test:
            n_levels = max(n_levels - 2, 2)

        # Without a reference solution the series runs one level further, so
        # that its finest level can serve as the reference of that method.
        if ref_file is None:
            n_levels += 1

        ax_discs.append(bench_func.disc_list(n_start, n_levels))

    n_methods = len(ax_methods)

    return {
        'cadet_config_jsons': [
            setting_Col1D_langLRM_2comp_benchmark1.get_model(
                spatial_method_bulk=0, column_geometry=column_geometry,
                col_dispersion=col_dispersion
                )
            ],
        'cadet_config_names': [
            GEOMETRY_NAMES[column_geometry] + '_LRM_langmuir_2comp_benchmark1'
            ],
        'include_sens': [False],
        'ref_files': [[ref_file] * n_methods],
        'unit_IDs': ['001'],
        'which': ['outlet'],
        'idas_abstol': [[idas_abstol] * n_methods],
        'ax_methods': [ax_methods],
        'ax_discs': [ax_discs],
        'par_methods': [[None] * n_methods],
        'par_discs': [[None] * n_methods],
        'disc_refinement_functions': [
            [bench_func.create_object_from_config] * n_methods
            ],
        }


def SMA_performance_benchmark(
        small_test=False, ref_file=None,
        column_geometry='AXIAL_FLOW_CYLINDER',
        particle_type='GENERAL_RATE_PARTICLE',
        idas_abstol=None):
    """Performance benchmark of the four-component load-wash-elute SMA setting.

    Fig. 5 of Breuer et al. (2023), doi:10.1016/j.compchemeng.2023.108340, on
    the refinement steps of the publication. A general rate particle is resolved
    in space and is refined along with the axial grid; any other particle type
    carries no particle grid, which leaves the bulk discretizations as the only
    difference between the methods.

    ref_file is the reference solution, shared by every spatial method, which is
    what makes the methods comparable to one another. Without one every series
    runs one level further and takes its own finest level as its reference.
    """

    if column_geometry not in GEOMETRY_NAMES:
        raise ValueError(
            'column_geometry must be one of ' + str(sorted(GEOMETRY_NAMES))
            + ', got ' + str(column_geometry) + '.'
            )

    # The WENO finite volume scheme and DG of degrees three to five, with their
    # refinement steps as (first level, number of levels), every level doubling
    # the resolution. Fig. 5 starts at four axial and one particle element and
    # shows FV up to 512 cells and 128 particle cells, DG P3 up to 32 and 8 and
    # DG P4 up to 16 and 4 elements; degree five repeats the steps of degree
    # four.
    ax_methods = [0, 3, 4, 5]
    if particle_type == 'GENERAL_RATE_PARTICLE':
        steps = {0: (4, 8), 3: (4, 4), 4: (4, 3), 5: (4, 3)}
    else:
        steps = {0: (4, 8), 3: (2, 4), 4: (2, 4), 5: (1, 4)}

    # Particle elements of the coarsest level, refined along with the axial grid.
    n_par_start = 1

    resolves_particle = particle_type == 'GENERAL_RATE_PARTICLE'

    if idas_abstol is None:
        idas_abstol = 1e-10 if resolves_particle else 1e-12
    ax_discs = []
    par_discs = []

    for method in ax_methods:

        n_start, n_levels = steps[method]

        # A small test runs two levels fewer per series, but never fewer than
        # two, since a single level is not a convergence study.
        if small_test:
            n_levels = max(n_levels - 2, 2)

        # Without a reference solution the series runs one level further, so
        # that its finest level can serve as the reference of that method.
        if ref_file is None:
            n_levels += 1

        ax_discs.append(bench_func.disc_list(n_start, n_levels))
        par_discs.append(
            bench_func.disc_list(n_par_start, n_levels)
            if resolves_particle else None
            )

    n_methods = len(ax_methods)

    return {
        'cadet_config_jsons': [
            setting_Col1D_SMA_4comp_LWE_benchmark1.get_model(
                spatial_method_bulk=0, column_geometry=column_geometry,
                particle_type=particle_type,
                **(dict(spatial_method_particle=0) if resolves_particle else {})
                )
            ],
        'cadet_config_names': [
            GEOMETRY_NAMES[column_geometry] + '_'
            + ('GRM' if resolves_particle else 'LRMP')
            + '_reqSMA_4comp_benchmark1'
            ],
        'include_sens': [False],
        'ref_files': [[ref_file] * n_methods],
        'unit_IDs': ['000'],
        'which': ['outlet'],
        'idas_abstol': [[idas_abstol] * n_methods],
        'ax_methods': [ax_methods],
        'ax_discs': [ax_discs],
        'par_methods': [
            [method if resolves_particle else None for method in ax_methods]
            ],
        'par_discs': [par_discs],
        'disc_refinement_functions': [
            [bench_func.create_object_from_config] * n_methods
            ],
        }


# %% Reference solutions of the column geometry performance benchmarks


# Discretization and time integration tolerance of the reference solution of each
# setting of the column geometry performance benchmarks, see
# scripts/verify_geometries.py. One reference per setting and geometry
# is shared by all spatial methods of that sweep, which is what makes the methods
# comparable to one another.
#
# Every resolution is beyond the finest level of the sweep it serves, at degree
# five, where the DG scheme has long left the oscillatory regime of the Langmuir
# setting. The Langmuir sweep already refines DG to 1024 elements, so its
# reference is one level beyond that; the two SMA sweeps are much coarser and
# their references sit several levels beyond their finest level.
#
# The tolerance is the one of Breuer et al. (2023),
# doi:10.1016/j.compchemeng.2023.108340, chosen there so that the spatial error
# dominates. create_object_from_config derives RELTOL and ALGTOL from ABSTOL as
# ABSTOL * 100, so 1e-12 gives the relative tolerance 1e-10 of the publication.
# At a looser tolerance every spatial method of a setting stops at the same
# error, which for the Langmuir setting on the radial geometry is an L1 error of
# about 2e-2, well above the range the benchmark is about.
GEOMETRY_REFERENCES = {
    'langmuir': {
        'polydeg': 5,
        'n_elements': 2048,
        'n_par_elements': None,
        'idas_abstol': 1e-10,
        'use_collocation_dg': 0,
        },
    'sma_lrmp': {
        'polydeg': 5,
        'n_elements': 256,
        'n_par_elements': None,
        'idas_abstol': 1e-12,
        'use_collocation_dg': 0,
        },
    'sma_grm': {
        'polydeg': 5,
        'n_elements': 64,
        'n_par_elements': 16,
        'idas_abstol': 1e-10,
        'use_collocation_dg': 0,
        },
    }


def geometry_reference(setting, column_geometry):
    """The reference solution of one column geometry performance benchmark.

    Returns everything needed to simulate the reference of the given setting on
    the given geometry: the model, the name the sweep expects the file under and
    the discretization and tolerance it is to be run with, which are the entry
    of GEOMETRY_REFERENCES.

    Parameters
    ----------
    setting : string
        One of the keys of GEOMETRY_REFERENCES.
    column_geometry : string
        One of the keys of GEOMETRY_NAMES.

    Returns
    -------
    dict
    """
    if setting not in GEOMETRY_REFERENCES:
        raise ValueError(
            'setting must be one of ' + str(sorted(GEOMETRY_REFERENCES))
            + ', got ' + str(setting) + '.'
            )

    if column_geometry not in GEOMETRY_NAMES:
        raise ValueError(
            'column_geometry must be one of ' + str(sorted(GEOMETRY_NAMES))
            + ', got ' + str(column_geometry) + '.'
            )

    reference = GEOMETRY_REFERENCES[setting]

    prefix = GEOMETRY_NAMES[column_geometry]

    if setting == 'langmuir':

        cadet_config_json = setting_Col1D_langLRM_2comp_benchmark1.get_model(
            spatial_method_bulk=0, column_geometry=column_geometry
            )
        setting_name = prefix + '_LRM_langmuir_2comp_benchmark1'
        unit_id = '001'
        par_method = None
        par_cells = None

    else:

        resolves_particle = setting == 'sma_grm'
        particle_type = (
            'GENERAL_RATE_PARTICLE' if resolves_particle
            else 'HOMOGENEOUS_PARTICLE'
            )

        cadet_config_json = setting_Col1D_SMA_4comp_LWE_benchmark1.get_model(
            spatial_method_bulk=0, column_geometry=column_geometry,
            particle_type=particle_type,
            **(dict(spatial_method_particle=0) if resolves_particle else {})
            )
        setting_name = (
            prefix + '_' + ('GRM' if resolves_particle else 'LRMP')
            + '_reqSMA_4comp_benchmark1'
            )
        unit_id = '000'
        par_method = reference['polydeg'] if resolves_particle else None
        par_cells = reference['n_par_elements'] if resolves_particle else None

        if resolves_particle and par_cells is None:
            raise ValueError(
                'the general rate particle of the SMA setting is resolved in '
                'space and so needs a number of particle elements.'
                )

    return {
        'cadet_config_json': cadet_config_json,
        'setting_name': setting_name,
        'unit_id': unit_id,
        'ax_method': reference['polydeg'],
        'ax_cells': reference['n_elements'],
        'par_method': par_method,
        'par_cells': par_cells,
        'idas_abstol': reference['idas_abstol'],
        'use_collocation_dg': reference['use_collocation_dg'],
        }

# Subdirectory of the data directory holding the reference solutions of the
# performance benchmarks, next to the transport references of the EOC studies,
# see src/geometry_references.py.
GEOMETRY_REFERENCE_SUBDIR = os.path.join('CADET-Core_reference', 'chromatography')


def geometry_reference_path(setting, column_geometry, data_dir):
    """Path of the stored reference solution of a performance benchmark.

    The file is named as the sweep names its own simulations, so that it is
    recognisable as the resolution it was computed at, see
    scripts/verify_geometries.py, which computes it.

    Parameters
    ----------
    setting : string
        One of the keys of GEOMETRY_REFERENCES.
    column_geometry : string
        One of the keys of GEOMETRY_NAMES.
    data_dir : string
        Path of the data directory.

    Returns
    -------
    string
    """
    reference = geometry_reference(setting, column_geometry)

    return bench_func.create_object_from_config(
        config_data=reference['cadet_config_json'],
        setting_name=reference['setting_name'],
        unit_id=reference['unit_id'],
        ax_method=reference['ax_method'],
        ax_cells=reference['ax_cells'],
        par_method=reference['par_method'],
        par_cells=reference['par_cells'],
        output_path=os.path.join(data_dir, GEOMETRY_REFERENCE_SUBDIR),
        only_return_name=True,
        include_sens=False,
        )


def geometry_reference_simulation(setting, column_geometry, data_dir,
                                  verbose=True):
    """The stored reference solution of a performance benchmark, or None.

    Handed to the benchmark configuration as its ref_file, which makes all of
    its spatial methods comparable to one another. A setting whose reference has
    not been computed yet is reported as None, upon which
    bench_func.run_convergence_analysis falls back to self-convergence, i.e.
    every method computes one level beyond its sweep and takes that as its own
    reference.

    Parameters
    ----------
    setting : string
        One of the keys of GEOMETRY_REFERENCES.
    column_geometry : string
        One of the keys of GEOMETRY_NAMES.
    data_dir : string
        Path of the data directory. None disables the references.
    verbose : bool
        Report which reference is used.

    Returns
    -------
    Cadet object or None
    """
    if data_dir is None:
        return None

    path = geometry_reference_path(setting, column_geometry, data_dir)
    name = os.path.basename(path)

    if os.path.exists(path):
        if verbose:
            print(f"{setting} on {GEOMETRY_NAMES[column_geometry]}: "
                  f"reference {name} for all methods")
        return convergence.get_simulation(path)

    if verbose:
        print(f"WARNING {setting} on {GEOMETRY_NAMES[column_geometry]}: the "
              f"reference {name} is not in the reference data directory, "
              "falling back to self-convergence")

    return None

# %% Further sensitivity benchmark configuration used in CADET-Core tests (FV and DG)


def sensitivity_benchmark1(spatial_method, small_test):
    
    if spatial_method not in ["DG", "FV"]:
        raise ValueError(
            f"spatial method must be FV or DG.")

    if spatial_method == "FV":
        spatial_method_polyDeg = 0
    elif spatial_method == "DG":
        spatial_method_polyDeg = 3

    benchmark_config = {
        'cadet_config_jsons': [
            setting_Col1D_lin_1comp_benchmark1.get_LRM_sensbenchmark1(
                spatial_method_bulk=spatial_method_polyDeg
                ),
            setting_Col1D_lin_1comp_benchmark1.get_LRMP_sensbenchmark1(
                spatial_method_bulk=spatial_method_polyDeg
                ),
            setting_Col1D_lin_1comp_benchmark1.get_GRM_sensbenchmark1(
               spatial_method_bulk=spatial_method_polyDeg,
               spatial_method_particle=spatial_method_polyDeg
               ),
            setting_Col1D_lin_1comp_benchmark1.get_GRM_sensbenchmark2(
               spatial_method_bulk=spatial_method_polyDeg,
               spatial_method_particle=spatial_method_polyDeg
               ),
            setting_Col1D_SMA_4comp_LWE_benchmark1.get_LRM_sensbenchmark1(
                spatial_method_bulk=spatial_method_polyDeg
                ),
            setting_Col1D_SMA_4comp_LWE_benchmark1.get_LRMP_sensbenchmark1(
                spatial_method_bulk=spatial_method_polyDeg
                ),
            setting_Col1D_SMA_4comp_LWE_benchmark1.get_GRM_sensbenchmark1(
               spatial_method_bulk=spatial_method_polyDeg,
               spatial_method_particle=spatial_method_polyDeg
               )
        ],
        'cadet_config_names': [
            'LRM_dynLin_1comp_sensbenchmark1',
            'LRMP_dynLin_1comp_sensbenchmark1',
            'GRM_dynLin_1comp_sensbenchmark1',
            'GRM_dynLin_1comp_sensbenchmark2',
            'LRM_reqSMA_4comp_sensbenchmark1',
            'LRMP_reqSMA_4comp_sensbenchmark1',
            'GRM_reqSMA_4comp_sensbenchmark1'
        ],
        'include_sens': [True] * 7,
        'ref_files': [
            [None], [None], [None], [None], [None], [None], [None]
        ],
        'unit_IDs': [
            '001', '001', '001', '001', '000', '000', '000'
        ],
        'which': [
            'outlet', 'outlet', 'outlet', 'outlet', 'outlet', 'outlet', 'outlet'
        ],
        'idas_abstol': [
            [1e-10], [1e-10], [1e-10], [1e-10], [1e-10], [1e-10], [1e-8]
        ],
        'ax_methods': [[3]] * 7 if spatial_method == "DG" else [[0]] * 7,
        'ax_discs': [
            [bench_func.disc_list(2 if spatial_method == "DG" else 8, 4 if not small_test else 3)],
            [bench_func.disc_list(2 if spatial_method == "DG" else 8, 4 if not small_test else 3)],
            [bench_func.disc_list(4 if spatial_method == "DG" else 8, 4 if not small_test else 3)],
            [bench_func.disc_list(4 if spatial_method == "DG" else 8, 4 if not small_test else 3)],
            [bench_func.disc_list(4 if spatial_method == "DG" else 8, 4 if not small_test else 3)],
            [bench_func.disc_list(4 if spatial_method == "DG" else 8, 4 if not small_test else 3)],
            [bench_func.disc_list(4 if spatial_method == "DG" else 8, 3 if not small_test else 3)]
        ],
        'par_methods':
            [[None], [None], [3], [3], [None], [None], [3]] if spatial_method == "DG" else [[None], [None], [0], [0], [None], [None], [0]],
        'par_discs': [
            [None],
            [None],
            [bench_func.disc_list(1 if spatial_method == "DG" else 2, 4 if not small_test else 3)],
            [bench_func.disc_list(1 if spatial_method == "DG" else 2, 4 if not small_test else 3)],
            [None],
            [None],
            [bench_func.disc_list(1 if spatial_method == "DG" else 2, 3 if not small_test else 3)]
        ]
    }

    return benchmark_config


def sensitivity_benchmark2(spatial_method, small_test):
    
    if spatial_method not in ["DG", "FV"]:
        raise ValueError(
            f"spatial method must be FV or DG.")

    if spatial_method == "FV":
        spatial_method_polyDeg = 0
    elif spatial_method == "DG":
        spatial_method_polyDeg = 3

    benchmark_config = {
        'cadet_config_jsons': [
            setting_COL1D_GRMparType2_dynLin_2comp_benchmark1.get_sensbenchmark1(
                spatial_method_bulk=spatial_method_polyDeg, 
                spatial_method_particle=spatial_method_polyDeg)
        ],
        'cadet_config_names': [
            'GRMparType2_dynLin_2comp_sensbenchmark1'
        ],
        'include_sens': [True] * 1,
        'ref_files': [
            [None] * 1
        ],
        'unit_IDs': [
            '001'
        ],
        'which': [
            'outlet'
        ],
        'idas_abstol': [
            [1e-8]
        ],
        'ax_methods': [[3]] * 1 if spatial_method == "DG" else [[0]] * 1,
        'ax_discs': [
            [bench_func.disc_list(2 if spatial_method == "DG" else 4, 4 if not small_test else 3)]
        ],
        'par_methods':
            [[3]] if spatial_method == "DG" else [[0]],
        'par_discs': [
            [bench_func.disc_list(1 if spatial_method == "DG" else 2, 4 if not small_test else 3)]
        ]
    }

    return benchmark_config


def radial_flow_benchmark_fv(small_test=False, sensitivities=False, ref_filepath=None):

    if ref_filepath is not None:
        ref_LRM = convergence.get_solution(ref_filepath+'/CADET-Core_reference/chromatography/radLRM_dynLin_1comp_benchmark1_DG_P3Z256.h5')
        ref_LRMP = convergence.get_solution(ref_filepath+'/CADET-Core_reference/chromatography/radLRMP_dynLin_1comp_benchmark1_DG_P3Z128.h5')
        ref_GRM = convergence.get_solution(ref_filepath+'/CADET-Core_reference/chromatography/radGRM_dynLin_1comp_benchmark1_cDG_P3Z128_DGexInt_parP3parZ16.h5')
    else:
        ref_LRM = None
        ref_LRMP = None
        ref_GRM = None

    benchmark_config = {
        'cadet_config_jsons': [
            setting_radCol1D_LRM_lin_1comp_benchmark1.get_sensbenchmark1(
                spatial_method_bulk=0
                ),
            setting_radCol1D_lin_1comp_benchmark1.get_LRMP_sensbenchmark1(
                spatial_method_bulk=0
                ),
            setting_radCol1D_lin_1comp_benchmark1.get_GRM_sensbenchmark1(
                spatial_method_bulk=0, spatial_method_par=0
                )
        ] if sensitivities else [
            setting_radCol1D_LRM_lin_1comp_benchmark1.get_model(
                spatial_method_bulk=0
                ),
            setting_radCol1D_lin_1comp_benchmark1.get_model(
                spatial_method_bulk=0, particle_type="HOMOGENEOUS_PARTICLE"
                ),
            setting_radCol1D_lin_1comp_benchmark1.get_model(
                spatial_method_bulk=0, spatial_method_par=0,
                particle_type="GENERAL_RATE_PARTICLE"
                )
        ],
        'cadet_config_names': [
            'radLRM_dynLin_1comp_sensbenchmark1',
            'radLRMP_dynLin_1comp_sensbenchmark1',
            'radGRM_dynLin_1comp_sensbenchmark1'
        ] if sensitivities else [
            'radLRM_dynLin_1comp_benchmark1',
            'radLRMP_dynLin_1comp_benchmark1',
            'radGRM_dynLin_1comp_benchmark1'
        ],
        'include_sens': [True] * 3 if sensitivities else [False] * 3,
        'ref_files': [
            [ref_LRM], [ref_LRMP], [ref_GRM]
        ],
        'unit_IDs': [
            '001', '001', '001'
        ],
        'which': [
            'outlet', 'outlet', 'outlet'
        ],
        'idas_abstol': [
            [1e-10], [1e-10], [1e-10]
        ],
        'ax_methods': [
            [0], [0], [0]
        ],
        'ax_discs': [
            [bench_func.disc_list(8, 11 if not small_test else 3)],
            [bench_func.disc_list(8, 7 if not small_test else 3)],
            [bench_func.disc_list(8, 5 if not small_test else 3)]
        ],
        'par_methods': [
            [None], [None], [0]
        ],
        'par_discs': [
            [None],
            [None],
            [bench_func.disc_list(1, 5 if not small_test else 3)]
        ],
        'disc_refinement_functions' : [
            [bench_func.create_object_from_config] for _ in range(3)
            ]
    }

    return benchmark_config


def radial_flow_benchmark_dg(small_test=False, sensitivities=False, ref_filepath=None):

    if ref_filepath is not None:
        ref_LRM = convergence.get_solution(ref_filepath+'/CADET-Core_reference/chromatography/radLRM_dynLin_1comp_benchmark1_DG_P3Z256.h5')
        ref_LRMP = convergence.get_solution(ref_filepath+'/CADET-Core_reference/chromatography/radLRMP_dynLin_1comp_benchmark1_DG_P3Z128.h5')
        ref_GRM = convergence.get_solution(ref_filepath+'/CADET-Core_reference/chromatography/radGRM_dynLin_1comp_benchmark1_cDG_P3Z128_DGexInt_parP3parZ16.h5')
    else:
        ref_LRM = None
        ref_LRMP = None
        ref_GRM = None

    benchmark_config = {
        'cadet_config_jsons': [
            setting_radCol1D_LRM_lin_1comp_benchmark1.get_sensbenchmark1(
                spatial_method_bulk=0
                ),
            setting_radCol1D_lin_1comp_benchmark1.get_LRMP_sensbenchmark1(
                spatial_method_bulk=0
                ),
            setting_radCol1D_lin_1comp_benchmark1.get_GRM_sensbenchmark1(
                spatial_method_bulk=0, spatial_method_par=0
                )
        ] if sensitivities else [
            setting_radCol1D_LRM_lin_1comp_benchmark1.get_model(
                spatial_method_bulk=0
                ),
            setting_radCol1D_lin_1comp_benchmark1.get_model(
                spatial_method_bulk=0, particle_type="HOMOGENEOUS_PARTICLE"
                ),
            setting_radCol1D_lin_1comp_benchmark1.get_model(
                spatial_method_bulk=0, spatial_method_par=0,
                particle_type="GENERAL_RATE_PARTICLE"
                )
        ],
        'cadet_config_names': [
            'radLRM_dynLin_1comp_sensbenchmark1',
            'radLRMP_dynLin_1comp_sensbenchmark1',
            'radGRM_dynLin_1comp_sensbenchmark1'
        ] if sensitivities else [
            'radLRM_dynLin_1comp_benchmark1',
            'radLRMP_dynLin_1comp_benchmark1',
            'radGRM_dynLin_1comp_benchmark1'
        ],
        'include_sens': [True] * 3 if sensitivities else [False] * 3,
        'ref_files': [
            [ref_LRM], [ref_LRMP], [ref_GRM]
        ],
        'unit_IDs': [
            '001', '001', '001'
        ],
        'which': [
            'outlet', 'outlet', 'outlet'
        ],
        'idas_abstol': [
            [1e-10], [1e-10], [1e-10]
        ],
        'ax_methods': [
            [3], [3], [3]
        ],
        'ax_discs': [
            [bench_func.disc_list(2, 7 if not small_test else 3)],
            [bench_func.disc_list(2, 5 if not small_test else 3)],
            [bench_func.disc_list(8, 4 if not small_test else 3)]
        ],
        'par_methods': [
            [None], [None], [3]
        ],
        'par_discs': [
            [None],
            [None],
            [bench_func.disc_list(1, 4 if not small_test else 3)]
        ],
        'disc_refinement_functions' : [
            [bench_func.create_object_from_config] for _ in range(3)
            ]
    }

    return benchmark_config


def check_input_config(disc_method, test_size, test_sizes):
    if not disc_method >= 0:
        raise Exception('disc_method must be 0 for FV or N_d > 0 for DG')
    if isinstance(test_size, str):
        if test_size not in ['large', 'mid', 'small']:
            raise ValueError(
                f"test_size must be integer or in ['large', 'mid', 'small'].")
        if str(disc_method) in test_sizes.keys():
            test_size = test_sizes[str(disc_method)].get(test_size, 'mid')
        else:
            raise ValueError(
                f"No defined test size {test_size} for disc_method {disc_method}.")
    elif not isinstance(test_size, int):
        raise Exception(
            'test_size must be integer or string (mid/large/small)')
    return test_size


def expand_dict(compact_dict):
    expanded_dict = {}
    for keys, value in compact_dict.items():
        for key in keys.split('|'):
            expanded_dict[key] = value
    return expanded_dict


def LRM_dynLin_1comp_benchmark1(
        disc_method, test_size='mid', include_sens=True, ref_file=None):

    adj = 0 if ref_file == None else 1
    test_sizes = {
        '0': {'large': 15 - adj, 'mid': 8, 'small': 3},
        '3|4|5': {'large': 9 - adj, 'mid': 5, 'small': 3}
    }
    test_sizes = expand_dict(test_sizes)

    test_size = check_input_config(disc_method, test_size, test_sizes)

    benchmark_config = {
        'cadet_config_jsons': [
            'LRM_dynLin_1comp_sensbenchmark1_FV_Z256.json'
        ],
        'include_sens': [include_sens],
        'ref_files': [
            [ref_file]
        ],
        'unit_IDs': [
            '001'
        ],
        'which': [
            'outlet'
        ],
        'idas_abstol': [
            [1e-8 if include_sens else 1e-10]
        ],
        'ax_methods': [
            [disc_method]
        ],
        'ax_discs': [
            [bench_func.disc_list(8 if disc_method == 0 else 1, test_size)]
        ],
        'par_methods': [
            [None]
        ],
        'par_discs': [
            [None]
        ]
    }
    return benchmark_config


def LRMP_dynLin_1comp_benchmark1(
        disc_method, test_size='mid', include_sens=True, ref_file=None):

    adj = 0 if ref_file == None else 1
    test_sizes = {
        '0': {'large': 12 - adj, 'mid': 6, 'small': 3},
        '3|4|5': {'large': 5 - adj, 'mid': 5, 'small': 3}
    }
    test_sizes = expand_dict(test_sizes)

    test_size = check_input_config(disc_method, test_size, test_sizes)

    benchmark_config = {
        'cadet_config_jsons': [
            'LRMP_dynLin_1comp_sensbenchmark1_FV_Z32.json'
        ],
        'include_sens': [include_sens],
        'ref_files': [
            [ref_file]
        ],
        'unit_IDs': [
            '001'
        ],
        'which': [
            'outlet'
        ],
        'idas_abstol': [
            [1e-8 if include_sens else 1e-10]
        ],
        'ax_methods': [
            [disc_method]
        ],
        'ax_discs': [
            [bench_func.disc_list(8, test_size)]
        ],
        'par_methods': [
            [disc_method]
        ],
        'par_discs': [
            [bench_func.disc_list(1 if disc_method == 0 else 1, test_size)]
        ]
    }
    return benchmark_config


def GRM_dynLin_1comp_benchmark1(
        disc_method, test_size='mid', include_sens=True, ref_file=None):

    adj = 0 if ref_file == None else 1
    test_sizes = {
        '0': {'large': 15 - adj, 'mid': 6, 'small': 3},
        '3|4|5': {'large': 9 - adj, 'mid': 5, 'small': 3}
    }
    test_sizes = expand_dict(test_sizes)

    test_size = check_input_config(disc_method, test_size, test_sizes)

    benchmark_config = {
        'cadet_config_jsons': [
            'GRM_dynLin_1comp_sensbenchmark1_FV_Z32parZ4.json'
        ],
        'include_sens': [include_sens],
        'ref_files': [
            [ref_file]
        ],
        'unit_IDs': [
            '001'
        ],
        'which': [
            'outlet'
        ],
        'idas_abstol': [
            [1e-8 if include_sens else 1e-10]
        ],
        'ax_methods': [
            [disc_method]
        ],
        'ax_discs': [
            [bench_func.disc_list(8 if disc_method == 0 else 1, test_size)]
        ],
        'par_methods': [
            [disc_method]
        ],
        'par_discs': [
            [bench_func.disc_list(1, test_size)]
        ]
    }
    return benchmark_config


def LRM_reqSMA_4comp_benchmark1(
        disc_method, test_size='mid', include_sens=True, ref_file=None):

    adj = 0 if ref_file == None else 1
    test_sizes = {
        '0': {'large': 12 - adj, 'mid': 5, 'small': 3},
        '3|4|5': {'large': 6 - adj, 'mid': 4, 'small': 3}
    }
    test_sizes = expand_dict(test_sizes)

    test_size = check_input_config(disc_method, test_size, test_sizes)

    benchmark_config = {
        'cadet_config_jsons': [
            'LRM_reqSMA_4comp_sensbenchmark1_FV_Z64.json'
        ],
        'include_sens': [include_sens],
        'ref_files': [
            [ref_file]
        ],
        'unit_IDs': [
            '000'
        ],
        'which': [
            'outlet'
        ],
        'idas_abstol': [
            [1e-8 if include_sens else 1e-10]
        ],
        'ax_methods': [
            [disc_method]
        ],
        'ax_discs': [
            [bench_func.disc_list(8 if disc_method == 0 else 4, test_size)]
        ],
        'par_methods': [
            [None]
        ],
        'par_discs': [
            [None]
        ]
    }
    return benchmark_config


def LRMP_reqSMA_4comp_benchmark1(
        disc_method, test_size='mid', include_sens=True, ref_file=None):

    adj = 0 if ref_file == None else 1
    test_sizes = {
        '0': {'large': 11 - adj, 'mid': 5, 'small': 3},
        '3|4|5': {'large': 6 - adj, 'mid': 4, 'small': 3}
    }
    test_sizes = expand_dict(test_sizes)

    test_size = check_input_config(disc_method, test_size, test_sizes)

    benchmark_config = {
        'cadet_config_jsons': [
            'LRMP_reqSMA_4comp_sensbenchmark1_FV_Z32.json'
        ],
        'include_sens': [include_sens],
        'ref_files': [
            [ref_file]
        ],
        'unit_IDs': [
            '000'
        ],
        'which': [
            'outlet'
        ],
        'idas_abstol': [
            [1e-8 if include_sens else 1e-10]
        ],
        'ax_methods': [
            [disc_method]
        ],
        'ax_discs': [
            [bench_func.disc_list(8 if disc_method == 0 else 4, test_size)]
        ],
        'par_methods': [
            [None]
        ],
        'par_discs': [
            [None]
        ]
    }
    return benchmark_config


def GRM_reqSMA_4comp_benchmark1(
        disc_method, test_size='mid', include_sens=True, ref_file=None):

    adj = 0 if ref_file == None else 1
    test_sizes = {
        '0': {'large': 11 - adj, 'mid': 5, 'small': 3},
        '3|4|5': {'large': 5 - adj, 'mid': 4, 'small': 3}
    }
    test_sizes = expand_dict(test_sizes)

    test_size = check_input_config(disc_method, test_size, test_sizes)

    benchmark_config = {
        'cadet_config_jsons': [
            'GRM_reqSMA_4comp_sensbenchmark1_FV_Z16parZ2.json'
        ],
        'include_sens': [include_sens],
        'ref_files': [
            [ref_file]
        ],
        'unit_IDs': [
            '000'
        ],
        'which': [
            'outlet'
        ],
        'idas_abstol': [
            [1e-7 if include_sens else 1e-8]
        ],
        'ax_methods': [
            [disc_method]
        ],
        'ax_discs': [
            [bench_func.disc_list(4, test_size)]
        ],
        'par_methods': [
            [disc_method]
        ],
        'par_discs': [
            [bench_func.disc_list(1, test_size)]
        ]
    }
    return benchmark_config


def linear_chromatography_benchmark(
        disc_method, test_size='mid', include_sens=True, ref_files=None):

    benchmark_config = LRM_dynLin_1comp_benchmark1(
        disc_method, test_size, include_sens, ref_files)

    merge_benchmark(benchmark_config,
                    LRMP_dynLin_1comp_benchmark1(
                        disc_method, test_size, include_sens, ref_files)
                    )
    merge_benchmark(benchmark_config,
                    GRM_dynLin_1comp_benchmark1(
                        disc_method, test_size, include_sens, ref_files)
                    )

    return benchmark_config


def LWE_chromatography_benchmark(
        disc_method, test_size='mid', include_sens=True, ref_files=None):

    benchmark_config = LRM_reqSMA_4comp_benchmark1(
        disc_method, test_size, include_sens, ref_files)

    merge_benchmark(benchmark_config,
                    LRMP_reqSMA_4comp_benchmark1(
                        disc_method, test_size, include_sens, ref_files)
                    )
    merge_benchmark(benchmark_config,
                    GRM_reqSMA_4comp_benchmark1(
                        disc_method, test_size, include_sens, ref_files)
                    )

    return benchmark_config


def chromatography_benchmark_without_GRMLWE(
        disc_method, test_size='mid', include_sens=True, ref_files=None):

    benchmark_config = LRM_reqSMA_4comp_benchmark1(
        disc_method, test_size, include_sens, ref_files)

    merge_benchmark(benchmark_config,
                    LRMP_reqSMA_4comp_benchmark1(
                        disc_method, test_size, include_sens, ref_files)
                    )
    merge_benchmark(benchmark_config,
                    linear_chromatography_benchmark(
                        disc_method, test_size, include_sens, ref_files)
                    )

    return benchmark_config


def full_chromatography_benchmark(
        disc_method, test_size='mid', include_sens=True, ref_files=None):

    benchmark_config = linear_chromatography_benchmark(
        disc_method, test_size, include_sens, ref_files)

    merge_benchmark(benchmark_config,
                    LWE_chromatography_benchmark(
                        disc_method, test_size, include_sens, ref_files)
                    )

    return benchmark_config


def GRM2D_FV_benchmark(small_test=False, **kwargs):

    nDisc = 4 if small_test else 6
    nRadialZones=kwargs.get('nRadialZones', 3)
    
    benchmark_config = {
        'cadet_config_jsons': [
            settings_2Dchromatography.GRM2D_linBnd_benchmark1(
                radNElem=nRadialZones,
                rad_inlet_profile=None,
                USE_MODIFIED_NEWTON=0, axMethod=0, **kwargs)
        ],
        'include_sens': [
            False
        ],
        'ref_files': [
            [kwargs.get('reference', None)]
        ],
        'refinement_ID': [
            '000'
        ],
        'unit_IDs': [ # note that we consider radial zone 0
            str(nRadialZones + 1 + 0).zfill(3) if kwargs.get('analytical_reference', 0) else '000'
        ],
        'which': [
            'outlet' if kwargs.get('analytical_reference', 0) else 'radial_outlet' # outlet_port_000
        ],
        'idas_abstol': [
            [1e-10]
        ],
        'ax_methods': [
            [0]
        ],
        'ax_discs': [
            [bench_func.disc_list(4, nDisc)]
        ],
        'rad_methods': [
            [0]
        ],
        'rad_discs': [
            [bench_func.disc_list(nRadialZones, nDisc)]
        ],
        'par_methods': [
            [0]
        ],
        'par_discs': [ # same number of particle cells as radial cells
            [bench_func.disc_list(nRadialZones, nDisc)]
        ]
    }

    return benchmark_config


def smb1_systems_tests(n_jobs, database_path, output_path,
                       cadet_path, small_test=False, **kwargs):

    nDisc = 4 if small_test else 5

    benchmark_config = {
        'cadet_config_jsons': [
            settings_columnSystems.SMB_model1(
                nDisc, 4, 1)
        ],
        'include_sens': [
            False
        ],
        'ref_files': [
            [None]
        ],
        'unit_IDs': [
            '003'
        ],
        'which': [
            'outlet'
        ],
        'idas_abstol': [
            [1e-10]
        ],
        'ax_methods': [
            [3]
        ],
        'ax_discs': [
            [bench_func.disc_list(4, nDisc)]
        ],
        'par_methods': [
            [None]
        ],
        'par_discs': [
            [None]
        ]
    }

    return benchmark_config


def cyclic_systems_tests(n_jobs, output_path,
                         cadet_path, small_test=False, **kwargs):

    # The analytical reference for the cyclic case has only ~1e-8 accuracy
    # Note that there is no proven error bound for the cyclic case, only estimations
    nDisc = 5 if kwargs.get('analytical_reference', False) else 7

    benchmark_config = {
        'cadet_config_jsons': [
            settings_columnSystems.Cyclic_model1(
                nDisc, 4, 1, analytical_reference=kwargs.get('analytical_reference', False))
        ],
        'include_sens': [
            False
        ],
        'ref_files': [
            [None]
        ],
        'unit_IDs': [
            '002' if kwargs.get('analytical_reference', False) else '003'
        ],
        'which': [
            'outlet'
        ],
        'idas_abstol': [
            [1e-12]
        ],
        'ax_methods': [
            [2]
        ],
        'ax_discs': [
            [bench_func.disc_list(1, nDisc)]
        ],
        'par_methods': [
            [None]
        ],
        'par_discs': [
            [None]
        ]
    }

    return benchmark_config


def acyclic_systems_tests(n_jobs, output_path,
                          cadet_path, small_test=False, **kwargs):

    nDisc = 5 if small_test else 5

    benchmark_config = {
        'cadet_config_jsons': [
            settings_columnSystems.Acyclic_model1(
                nDisc, 4, 1, analytical_reference=kwargs.get('analytical_reference', False))
        ],
        'include_sens': [
            False
        ],
        'ref_files': [
            [None]
        ],
        'unit_IDs': [
            '006'
        ],
        'which': [
            'outlet'
        ],
        'idas_abstol': [
            [1e-12]
        ],
        'ax_methods': [
            [3]
        ],
        'ax_discs': [
            [bench_func.disc_list(4, nDisc)]
        ],
        'par_methods': [
            [None]
        ],
        'par_discs': [
            [None]
        ]
    }

    return benchmark_config


def smb_systems_tests(n_jobs, output_path,
                       cadet_path, small_test=False, **kwargs):

    nDisc = 3 if small_test else 6

    benchmark_config = {
        'cadet_config_jsons': [
            settings_columnSystems.SMB_model1(nDisc, 3, 1)
        ],
        'include_sens': [
            False
        ],
        'ref_files': [
            [None]
        ],
        'unit_IDs': [
            '003'
        ],
        'which': [
            'outlet'
        ],
        'idas_abstol': [
            [1e-10]
        ],
        'ax_methods': [
            [3]
        ],
        'ax_discs': [
            [bench_func.disc_list(3, nDisc)]
        ],
        'par_methods': [
            [None]
        ],
        'par_discs': [
            [None]
        ]
    }

    return benchmark_config


def merge_benchmark(benchmark_config1, benchmark_config2):

    for key in benchmark_config1.keys():
        benchmark_config1[key].extend(benchmark_config2[key])


def add_benchmark(cadet_config_jsons, include_sens, ref_files, unit_IDs, which,
                  ax_methods, ax_discs,
                  par_methods=None, par_discs=None,
                  rad_methods=None, rad_discs=None,
                  idas_abstol=None,
                  refinement_IDs=None,
                  cadet_config_names=None,
                  addition=None,
                  disc_refinement_functions = None):

    if addition is None:
        addition = {}

    cadet_config_jsons.extend(addition['cadet_config_jsons'])
    include_sens.extend(addition['include_sens'])
    ref_files.extend(addition['ref_files'])
    unit_IDs.extend(addition['unit_IDs'])
    which.extend(addition['which'])
    
    ax_methods.extend(addition['ax_methods'])
    ax_discs.extend(addition['ax_discs'])
    
    if idas_abstol is not None:
        idas_abstol.extend(addition['idas_abstol'])
    if disc_refinement_functions is not None:
        disc_refinement_functions.extend(addition['disc_refinement_functions'])
    if par_methods is not None:
        par_methods.extend(addition['par_methods'])
        par_discs.extend(addition['par_discs'])
    if rad_methods is not None:
        rad_methods.extend(addition['rad_methods'])
        rad_discs.extend(addition['rad_discs'])
    if refinement_IDs is not None:
        if 'refinement_ID' in addition.keys():
            refinement_IDs.extend(addition['refinement_ID'])
    if cadet_config_names is not None:
        cadet_config_names.extend(addition['cadet_config_names'])
        
